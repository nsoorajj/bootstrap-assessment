import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import NavComp from './components/nav.component';
import CaroselComp from './components/carousel.component';
import CardComp from './components/card.component';
import MainComp1 from './components/main1.component';
import MainComp2 from './components/main2.component';
import MainComp3 from './components/main3.component';
import FooterComp from './components/footer.component';
 
class MainApp extends Component{
      render(){
            return <div>
                       <NavComp /> 
                       <CaroselComp />
                       <CardComp />
                       <MainComp1 /> 
                       <MainComp2 /> 
                       <MainComp3 />  
                       <FooterComp /> 
                  </div>
      }
};
 
ReactDOM.render(<MainApp/>,  document.getElementById('root') );