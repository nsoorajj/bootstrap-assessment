import React, { Component } from 'react';
import img5 from './img5.jpg';

class MainComp1 extends React.Component {
    render() { 
        return <div>
                <div class="container-fluid m-5">
                    <div class="d-flex flex-row ">
                        <div className="main-text">
                            <h1 className="fs-1 text-dark"> First featurette heading. It’ll blow your mind. </h1>
                            <p className ="fs-3 text-secondary"> Some great placeholder content for the first featurette here. Imagine some exciting prose here.</p>
                        </div>
                        <div>
                            <img src={img5} className="main-img"/>
                        </div>    
                    </div>
               
                </div>
                <hr />
            </div>
        
                
        
            }
};
 
export default MainComp1;