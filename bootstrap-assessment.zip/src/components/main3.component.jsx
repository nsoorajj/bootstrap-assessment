import React, { Component } from 'react';
import img7 from './img7.jpg';

class MainComp3 extends React.Component {
    render() { 
        return <div>
                <div class="container-fluid m-5">
                    <div class="d-flex flex-row justify-content-between">
                        <div className="main-text">
                            <h1 className="fs-1 text-dark"> And lastly, this one. Checkmate. </h1>
                            <p className ="fs-3 text-secondary">  And yes, this is the last block of representative placeholder content. Again, not really intended to be actually read, simply here to give you a better view of what this would look like with some actual content. Your content.</p>
                        </div>

                        <div>
                            <img src={img7} className="main-img"/>
                        </div>    
                    </div>
                </div>
              <hr />  
        </div>
        
        
            }
};
 
export default MainComp3;