import React, { Component } from 'react';
import img6 from './img6.jpg';

class MainComp2 extends React.Component {

    render() { 
        return <div>
                        <div class="container-fluid m-5">
                            <div class="d-flex flex-row justify-content-between">
                            <div>
                                <img src={img6} className="main2-img"/>
                            </div> 
                            <div className="main2-text">
                                    <h1 className="fs-1 text-dark">Oh yeah, it’s that good. See for yourself. </h1>
                                    <p className ="fs-3 text-secondary"> Another featurette? Of course. More placeholder content here to give you an idea of how this layout would work with some actual real-world content in place.</p>
                            </div>      
                            </div>
                        </div>
                    <hr />
                </div>
        
    }
};
 
export default MainComp2;