import React, { Component } from 'react';
class FooterComp extends React.Component {
    render() { 
        return <div className="container-fluid d-flex flex-row justify-content-between m-5" >
                    <div className="">   
                        <span className="fs-2 text-secondary"> &copy; 2017-2021 Company, Inc.</span> * <a href="" className="text-primary, fs-2">Privacy</a> * <a href="" className="text-primary, fs-2"> Terms</a> 
                    </div>
                    <div className="back-to-top">
                        <a href="" className="text-primary fs-2"> Back to top </a>
                    </div>

                </div>
    };
}
 
export default FooterComp;