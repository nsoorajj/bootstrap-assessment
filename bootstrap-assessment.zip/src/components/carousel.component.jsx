import React, { Component } from 'react';
import img1 from './img1.jpg';
import img2 from './img2.jpg';
import img3 from './img3.jpg';
import img4 from './img4.jpg';
class CaroselComp extends React.Component {
    render() { 
        return <div>
                    <div id="carouselExampleDark" className="carousel carousel-light slide h-75" data-bs-ride="carousel">
                        <div className="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div className="carousel-inner ">
                            <div className="carousel-item active" data-bs-interval="10000">
                            <img src={img4} className="d-block w-100 carousel-img" alt="This is image one" />
                            <div className="carousel-caption d-none d-md-block text-start" >
                                <h5 className="text-white fs-1 fw-bold">Example Headline</h5>
                                <p className="text-white fs-2 fw-bold">Some representative placeholder content for the first slide.</p>
                                <button className="btn btn-primary fs-3 p-2"> Sign up today </button>
                            </div>
                            </div>
                           
                            <img src={img2}  className="d-block w-100 h-75 carousel-img" alt="This is image two" />
                            <div className="carousel-caption d-none d-md-block">
                                <h5 className="text-white fs-4 fw-bold">Second slide label</h5>
                                <p className="text-white fs-4 fw-bold">Some representative placeholder content for the second slide.</p>
                                <button className="btn btn-primary fs-3 p-2"> Learn More </button>
                            
                            </div>
                            <div className="carousel-item">
                            <img src={img3} className="d-block w-100 h-75 carousel-img" alt="This is image three" />
                            <div className="carousel-caption d-none d-md-block">
                                <h5>Third slide label</h5>
                                <p>Some representative placeholder content for the third slide.</p>
                            </div>
                            </div>
                        </div>
                        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span className="visually-hidden">Previous</span>
                        </button>
                        <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                            <span className="carousel-control-next-icon" aria-hidden="true"></span>
                            <span className="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
    }
};
 
export default CaroselComp;