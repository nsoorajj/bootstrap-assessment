import React, { Component } from 'react';
import img1 from './img1.jpg';
import img2 from './img2.jpg';
import img3 from './img3.jpg';

class CardComp extends React.Component {
    render() { 
        return <div>
                    <div className="container-fluid d-flex flex-row">
                        <div className=" w-25 m-auto mt-3">
                            <img src={img1} className="card-img-top card-img" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title fs-2 text-center">Card title</h5>
                                <p className="card-text fs-5 text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <div className="text-center">
                                    <a href="" className="btn btn-secondary fs-3">View details</a>
                                </div>
                                
                            </div>
                        </div>
                        <div className="w-25 m-auto mt-3">
                            <img src={img2} className="card-img-top card-img" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title fs-2 text-center">Card title</h5>
                                <p className="card-text fs-5 text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <div className="text-center">
                                    <a href="" className="btn btn-secondary fs-3">View details</a>
                                </div>
                                
                            </div>
                        </div>
                        <div className="w-25 m-auto mt-3">
                            <img src={img3} className="card-img-top card-img" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title fs-2 text-center">Card title</h5>
                                <p className="card-text fs-5 text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                <div className="text-center">
                                    <a href="" className="btn btn-secondary fs-3">View details</a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <hr />
                </div>
        
    }
};
 
export default CardComp;